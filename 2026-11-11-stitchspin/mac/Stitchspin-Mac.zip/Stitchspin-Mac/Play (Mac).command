#!/bin/bash
# Stitchspin — make the app ready for THIS Mac and open it.
#
# The app was built on Windows, so it carries no signature, and a zip from the internet is marked by macOS as
# downloaded. This script clears that mark, makes the game's binary runnable, signs the app for this Mac only (an
# ad-hoc signature: Apple silicon runs an arm64 binary only when it is signed) and opens it. Nothing else on the Mac is
# touched. Double-click it, or in Terminal: bash "Play (Mac).command".

DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/Stitchspin.app"
echo "Stitchspin · opening the game on this Mac"
echo
if [ ! -d "$APP" ]; then
  echo "Stitchspin.app is not next to this script ($DIR)."
  read -r -p "Press Return to close." _
  exit 1
fi

xattr -cr "$APP" 2>/dev/null
BIN="$(ls "$APP/Contents/MacOS" | head -n 1)"
chmod +x "$APP/Contents/MacOS/$BIN"
if [ "$(uname -m)" = "arm64" ]; then
  if codesign --force --deep --sign - "$APP" > /dev/null 2>&1; then
    echo "The app is signed for this Mac (ad hoc)."
    open "$APP"
  else
    echo "The ad-hoc signature failed: the game opens through Rosetta instead."
    arch -x86_64 "$APP/Contents/MacOS/$BIN" -screen-fullscreen 0 -screen-width 390 -screen-height 845 &
  fi
else
  open "$APP"
fi
echo
echo "From now on Stitchspin.app opens by a double-click."
sleep 2
