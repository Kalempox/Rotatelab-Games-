#!/bin/bash
# Stitchspin — the 90 fps floor measured on THIS Mac (hcu PORT-GUIDE Step 6.6; CD 2026-10-05: every platform is measured
# on its own machine, proven by its own frames).
#
# Double-click it, or in Terminal: bash "Run perf test.command". The game runs by itself four times, thirty seconds each,
# about two and a half minutes in all (do not touch the mouse or the keyboard while it runs; the bot LOSES on purpose in
# the first run):
#   1. THE GAME AS SHIPPED, the lose bot over level 4 — the loop full of riding bobbins, the rack filling;
#   2. THE GAME AS SHIPPED, the win bot over level 5 — the figure with the most cubes (586), every cube standing at its
#      start, five bobbins riding and pulling;
#   then two DIAGNOSTIC variants of run 2 (never the shipped game — they say where a Mac's cost lives):
#   3. noshell — the shell pass (hc's menus and HUD drawn over the board) left out of the measured window;
#   4. scale50 — everything drawn at half the resolution (is the GPU's fill rate the limit?).
# Uncapped (no vSync, no frame-rate limit). The floor: an average of at least 90 fps and a p95 frame of at most 11.1 ms.
# Each run also reads the engine's own CPU and GPU milliseconds per frame. The report hcu-perf-mac.json (this Mac's
# model, chip, macOS and screen, every run) and the frames go to stitchspin-perf-mac/ next to this script, and
# stitchspin-perf-mac.zip is put on the Desktop: send that zip back.

DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/Stitchspin.app"
OUT="$DIR/stitchspin-perf-mac"
mkdir -p "$OUT"
echo "Stitchspin · the perf run on this Mac"
echo
if [ ! -d "$APP" ]; then
  echo "Stitchspin.app is not next to this script ($DIR)."
  read -r -p "Press Return to close." _
  exit 1
fi

# a zip from the internet is quarantined by macOS; the app was built on Windows, so it carries no signature
xattr -cr "$APP" 2>/dev/null
BIN="$(ls "$APP/Contents/MacOS" | head -n 1)"
EXE="$APP/Contents/MacOS/$BIN"
chmod +x "$EXE"
PREFIX=""
if [ "$(uname -m)" = "arm64" ]; then
  # Apple silicon runs an arm64 binary only when it is signed: an ad-hoc signature is made here, on this Mac
  if codesign --force --deep --sign - "$APP" > "$OUT/codesign.txt" 2>&1; then
    MODE="native arm64 (signed ad hoc on this Mac)"
  else
    PREFIX="arch -x86_64"
    MODE="x86_64 through Rosetta (the ad-hoc signature failed: see codesign.txt)"
  fi
else
  MODE="native x86_64"
fi
echo "The game runs: $MODE"
echo

# measure <name> <level> <load> <seconds> <diagnostic> <what>
measure() {
  echo "Measuring $1: $6 ..."
  $PREFIX "$EXE" -screen-fullscreen 0 -screen-width 390 -screen-height 845 \
    -logFile "$OUT/player-$1.log" -hcuPerf "$2" "$4" "$OUT/perf-$1.json" "$3" -hcuDiag "$5"
  if [ -f "$OUT/perf-$1.txt" ]; then head -n 2 "$OUT/perf-$1.txt"; else echo "  (no report: see player-$1.log)"; fi
  echo
}
measure lose 4 lose 30 none "the game as shipped, the lose bot over level 4 (the loop full, the rack filling)"
measure swarm 5 swarm 30 none "the game as shipped, the win bot over level 5 (586 cubes standing at its start)"
measure noshell 5 swarm 30 noshell "diagnostic: run 2 without the shell pass"
measure scale50 5 swarm 30 scale50 "diagnostic: run 2 at half the resolution"

DISPLAYS="$(system_profiler SPDisplaysDataType 2>/dev/null | grep -E 'Chipset Model|Resolution|Refresh' | sed 's/^ *//' | tr '\n' ';' | tr -d '"\\')"
{
  echo "{"
  echo "  \"tool\": \"Run perf test.command (stitchspin Mac package)\","
  echo "  \"at\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\","
  echo "  \"mode\": \"$MODE\","
  echo "  \"macos\": \"$(sw_vers -productVersion) ($(sw_vers -buildVersion))\","
  echo "  \"model\": \"$(sysctl -n hw.model 2>/dev/null)\","
  echo "  \"chip\": \"$(sysctl -n machdep.cpu.brand_string 2>/dev/null | tr -d '"\\')\","
  echo "  \"arch\": \"$(uname -m)\","
  echo "  \"displays\": \"$DISPLAYS\","
  for run in lose swarm noshell; do
    if [ -f "$OUT/perf-$run.json" ]; then echo "  \"$run\": $(cat "$OUT/perf-$run.json"),"; else echo "  \"$run\": null,"; fi
  done
  if [ -f "$OUT/perf-scale50.json" ]; then echo "  \"scale50\": $(cat "$OUT/perf-scale50.json")"; else echo "  \"scale50\": null"; fi
  echo "}"
} > "$OUT/hcu-perf-mac.json"

rm -f "$HOME/Desktop/stitchspin-perf-mac.zip"
ditto -c -k --keepParent "$OUT" "$HOME/Desktop/stitchspin-perf-mac.zip"
echo "The report and the frames: $OUT"
echo "Send this file back: $HOME/Desktop/stitchspin-perf-mac.zip"
open "$OUT"
echo
read -r -p "Press Return to close." _
